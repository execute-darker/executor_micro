#!/system/bin/sh
MODDIR=${0%/*}
wait_until_login() {
while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 1
done
local test_file="/data/media/0/.PERMISSION_TEST"
true >"$test_file"
while [ ! -f "$test_file" ]; do
true >"$test_file"
sleep 1
done
rm "$test_file"
}
wait_until_login
rm -rf /data/adb/modules*/uperf_enhance*
mkdir /data/media/0/Android/MTK-Enhance
rm -rf /data/media/0/Android/MTK-Enhance.log
rm -rf /data/media/0/Android/MTK-Enhance.lastboot.log
mv /data/media/0/Android/MTK-Enhance/MTK-Enhance.log /data/media/0/Android/MTK-Enhance/MTK-Enhance.lastboot.log
$MODDIR/MTK-Enhance_main >/data/media/0/Android/MTK-Enhance/MTK-Enhance.log &
sh $MODDIR/servicelast.sh &
