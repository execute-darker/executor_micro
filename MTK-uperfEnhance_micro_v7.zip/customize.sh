if [ -f "/data/adb/modules_update/uperf/service.sh" ]; then
ising=/data/adb/modules_update/uperf
else
ising=/data/adb/modules/uperf
fi
set_perm_recursive  $MODPATH  0  0  0775  0775
fuckhamjin() {
if [ "$1" != "1" ]; then
for i in $2
do
if [ $(grep_prop versionCode $ising/module.prop) == $i ]; then
cp $MODPATH/patchfile/$i.sh $ising/script
mv $MODPATH/patchfile/$i.sh $ising/script/$3
fi
done
else
if [ "$ising" == "/data/adb/modules/uperf" ]; then
md5="$(md5sum -c $MODPATH/patchfile/$2.md5)"
else
md5="$(md5sum -c $MODPATH/patchfile/$2.up.md5)"
fi
if [ "$md5" == "$ising/script/$2: OK" ]; then
cp $MODPATH/patchfile/$2 $ising/script
mv $MODPATH/patchfile/$2 $ising/script/$2
fi
fi
}
_re0()
{
if [ -f "$ising/servicelast.sh" ]; then
mv $ising/module.prop.old $ising/module.prop
mv $ising/servicelast.sh $ising/service.sh
mv $ising/post-fs-data.sh.old $ising/post-fs-data.sh
mv $ising/system.prop.old $ising/system.prop
mv $ising/uninstall.sh.old $ising/uninstall.sh
rm -rf $ising/servicelast.sh
rm -rf $ising/MTK-Enhance_main*
fi
}
volume_keytest() {
echo "
- *******************************

- 𝕌𝕡𝕖𝕣𝕗 𝕄𝕋𝕂-𝔼𝕟𝕙𝕒𝕟𝕔𝕖 𝕗𝕚𝕩 *微型版

- 版本: $(grep_prop versionCode $MODPATH/module.prop)
- 作者：world.execute(darker); 酷安@darker_fun && HamJTY 酷安@HamJin
- *******************************
- 有可能导致开机开机卡屏、无限重启、开机完成后经常自动重启等风险- - - - - -
- 甚至可能造成设备损坏等不可逆损失!！- - - - - -
- 对造成的损失作者将不负责。- - - - - -
- 需要装好有效救砖模块。- - - - - -
- 或者准备可以有效解密data分区的recovery- - - - - -
- 如想取消安装，请在之后选择第二项卸载- - - - - -
- *******************************
- 用户温控检测配置调整文件，可以在/sdcard/Android/MTK-Enhance/cfg_enhance.prop里调整温度检测的阈值。

- 运行log位置: /sdcard/Android/MTK-Enhance/MTK-Enhance.log
- *******************************
--- 音量键测试 ---

  请按音量+或-键"
(/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
return 0
}
volume_choose() {
while (true); do
/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
break
fi
done
if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
return 1
else
return 0
fi
}
volume_key_test() {
if volume_keytest; then
KEYTEST=volume_choose
echo "- 音量键测试完成

"
else
KEYTEST=false
rm -rf /data/adb/modules/U-executor_info
abort "

 ！错误：没有检测到音量键选择
 
- 已回复原版uperf并取消安装
"
fi
sleep 0.5
}
chk () {
if [ -f "/proc/mtktz/mtktscpu" ]; then
name="uperf"
count=`ps -ef | grep $name | grep -v "grep" | wc -l`
if [[ $count == 0 ]];then
abort "

- 请先安装uperf！

"
fi
else
abort "

- 你的设备不是联发科或不支持！

"
fi
}
ins() {
echo "
--- 请选择是否安装模块 ---

  音量+键 = 安装,安装uperf_Enhance(只有解锁cpu温度墙功能)
  
  音量-键 = 卸载,回复原版uperf
"
sleep 0.5s
if "$KEYTEST"; then
rm -rf /data/adb/modules/U-executor_info
echo "
- 已回复原版uperf功能
"
else
if [ -f "$ising/service.sh" ]; then
mv $ising/service.sh $ising/servicelast.sh
else
echo "" $ising/servicelast.sh
fi
echo "
- 正在安装。。。
"
mkdir /data/media/0/Android/MTK-Enhance
mkdir /data/adb/modules/U-executor_info
cp $MODPATH/service.sh $ising
cp $MODPATH/MTK-Enhance_main $ising
cp $MODPATH/patchfile/cfg_enhance.prop /data/media/0/Android/MTK-Enhance
cp $MODPATH/module.prop /data/adb/modules/U-executor_info
fuckhamjin '220926000' mtk_special.sh
fuckhamjin 1 powercfg_main.sh
rm -rf /data/adb/modules*/uperf_enhance*
rm -rf $TMPDIR
rm -rf /data/adb/modules_update/U-executor_info
echo "- 安装完成"
exit 0
fi
}
ising=/data/adb/modules/uperf
MODAUTHOR=`grep_prop author $TMPDIR/module.prop` && [ $MODAUTHOR != "world.execute(darker); 酷安@darker_fun" ] && abort "



- NMSL


"
if [ -f "$ising/update" ]; then
if [ -f "/data/adb/modules_update/uperf/service.sh" ]; then
ising=/data/adb/modules_update/uperf
_re0
volume_key_test
ins
fi
else
chk
_re0
volume_key_test
ins
fi
